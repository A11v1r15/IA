#include <iostream>
#include "StateSleep.h"
#include "StateEating.h"
#include "Troll.h"

using namespace std;

int main(){
    bool loop = true;
    StateSleep sleep;
    StateEating  eat;
    Troll troll(&sleep);
    troll.Update();
    while(loop){
        char q;
        cout << "Pressione 1 para dormir" << endl;
        cout << "Pressione 2 para comer" << endl;
        cout << "Pressione 0 para sair" << endl;
        cin >> q;
        if(q == '1'){
            troll.ChangeState(&sleep);
        } else if(q == '2'){
            troll.ChangeState(&eat);
        } else if(q == '0'){
            loop = false;
        }
        troll.Update();
    }
    return 0;
}
