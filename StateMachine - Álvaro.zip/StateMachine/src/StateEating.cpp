#include "StateEating.h"

void StateEating::Execute(Troll* troll){
    cout << "Comendo" << endl;
}
void StateEating::Enter(Troll* troll){
    cout << "Preparando comida" << endl;
}

void StateEating::Exit(Troll* troll){
    cout << "Buchin chei" << endl;
}
