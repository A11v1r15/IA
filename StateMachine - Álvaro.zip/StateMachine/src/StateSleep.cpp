#include "StateSleep.h"

void StateSleep::Execute(Troll* troll){
    cout << "Dormindo" << endl;
}

void StateSleep::Enter(Troll* troll){
    cout << "Indo Dormir" << endl;
}

void StateSleep::Exit(Troll* troll){
    cout << "Acordando" << endl;
}
