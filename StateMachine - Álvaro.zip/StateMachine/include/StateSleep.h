#ifndef STATESLEEP_H
#define STATESLEEP_H

#include "State.h"

class StateSleep : public State{
    public:
        void Execute(Troll* troll);
        void Enter(Troll* troll);
        void Exit(Troll* troll);

    protected:

    private:
};

#endif // STATESLEEP_H
