#ifndef STATE_H
#define STATE_H
#include <iostream>
using namespace std;

class Troll;

class State{
    public:
        virtual void Execute(Troll *) = 0;
        virtual void Enter(Troll *) = 0;
        virtual void Exit(Troll *) = 0;

    protected:

    private:
};

#endif // STATE_H
