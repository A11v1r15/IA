#ifndef STATEEATING_H
#define STATEEATING_H

#include <State.h>


class StateEating : public State{
    public:
        void Execute(Troll* troll);
        void Enter(Troll* troll);
        void Exit(Troll* troll);

    protected:

    private:
};

#endif // STATEEATING_H
